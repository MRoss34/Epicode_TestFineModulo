-- CREAZIONE E USO DATABASE
CREATE DATABASE toysgroupdb
USE toysgroupdb

-- CREAZIONE TABELLA ZONE DI VENDITA
CREATE TABLE SALES_REGION (
    sales_region_id INTEGER,
    sales_region_name VARCHAR(16),
    PRIMARY KEY (sales_region_id)
)

-- CREAZIONE TABELLA PAESI
CREATE TABLE COUNTRIES (
    country_id VARCHAR(3),
    country_name VARCHAR(16),
    sales_region_id INTEGER,
    PRIMARY KEY (country_id),
    FOREIGN KEY (sales_region_id)
        REFERENCES SALES_REGION (sales_region_id)
)

-- CREAZIONE TABELLA CATEGORIE DI PRODOTTO
CREATE TABLE PRODUCT_CATEGORIES (
    category_id INTEGER,
    category_name VARCHAR(16),
    PRIMARY KEY (category_id)
)

-- CREAZIONE TABELLA PRODOTTI
CREATE TABLE PRODUCTS (
    product_id INTEGER,
    product_name VARCHAR(16),
    product_price INTEGER,
    category_id INTEGER,
    PRIMARY KEY (product_id),
    FOREIGN KEY (category_id)
        REFERENCES PRODUCT_CATEGORIES (category_id)
)

-- CREAZIONE TABELLA VENDITE
CREATE TABLE SALES (
    order_id INTEGER AUTO_INCREMENT,
    order_date DATE,
    product_id INTEGER,
    country_id VARCHAR(3),
    PRIMARY KEY (order_id),
    FOREIGN KEY (product_id)
        REFERENCES PRODUCTS (product_id),
    FOREIGN KEY (country_id)
        REFERENCES COUNTRIES (country_id)
)

-- INSERIMENTO DATI ALL'INTERNO DELLE TABELLE
INSERT INTO SALES_REGION (sales_region_id, sales_region_name) VALUES
(1, 'North America'),
(2, 'Europe'),
(3, 'Asia')

INSERT INTO COUNTRIES (country_id, country_name, sales_region_id) VALUES
('CAN', 'Canada', 1),
('USA', 'United States', 1),
('MEX', 'Mexico', 1),
('ITA', 'Italy', 2),
('DEU', 'Germany', 2),
('NLD', 'Netherlands', 2),
('JPN', 'Japan', 3),
('KOR', 'South Korea', 3),
('RUS', 'Russia', 3)

INSERT INTO PRODUCT_CATEGORIES (category_id, category_name) VALUES
(1, 'Bambole'),
(2, 'Puzzle'),
(3, 'Giochi da tavolo')

INSERT INTO PRODUCTS (product_id, product_name, product_price, category_id) VALUES
(11, 'Ironman', 10, 1),
(12, 'Barbie', 20, 1),
(13, 'Superman', 30, 1),
(21, 'Puzzle 500pz', 10, 2),
(22, 'Puzzle 1000pz', 20, 2),
(23, 'Puzzle 2000pz', 30, 2),
(31, 'Monopoli', 10, 3),
(32, 'Risiko', 20, 3),
(33, 'Coloni di Catan', 30, 3)

INSERT INTO SALES (order_id, order_date, product_id, country_id)
VALUES
(1, '2022-01-15', 13, 'USA'),
(2, '2022-02-20', 31, 'DEU'),
(3, '2022-03-10', 22, 'ITA'),
(4, '2022-04-05', 31, 'CAN'),
(5, '2022-05-12', 32, 'JPN'),
(6, '2022-06-25', 21, 'ITA'),
(7, '2022-07-08', 33, 'KOR'),
(8, '2022-08-14', 11, 'NLD'),
(9, '2022-09-22', 31, 'RUS'),
(10, '2022-10-18', 13, 'ITA'),
(11, '2022-11-30', 22, 'USA'),
(12, '2022-12-05', 11, 'CAN'),
(13, '2023-01-08', 32, 'DEU'),
(14, '2023-02-17', 33, 'JPN'),
(15, '2023-03-22', 31, 'MEX'),
(16, '2023-04-03', 21, 'ITA'),
(17, '2023-05-11', 22, 'CAN'),
(18, '2023-06-19', 13, 'DEU'),
(19, '2023-07-27', 32, 'NLD'),
(20, '2023-08-10', 11, 'KOR'),
(21, '2023-08-15', 31, 'RUS'),
(22, '2023-08-20', 33, 'USA'),
(23, '2023-09-02', 21, 'ITA'),
(24, '2023-09-12', 22, 'CAN'),
(25, '2023-10-25', 31, 'JPN'),
(26, '2023-10-08', 11, 'ITA'),
(27, '2023-11-14', 33, 'KOR'),
(28, '2023-11-21', 13, 'DEU'),
(29, '2023-12-29', 22, 'NLD'),
(30, '2023-12-06', 31, 'ITA')

-- ESECUZIONE QUERY

-- Verificare che i campi definiti come PK siano univoci. per verificare le altre PK basta sostituire la PK all'interno delle parentesi con quella desiderata e modificare il nome unique_***

SELECT 
    COUNT(order_id) AS total_rows,
    COUNT(DISTINCT order_id) AS unique_order_ids
FROM
    SALES

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
    P.product_id,
    P.product_name,
    YEAR(S.order_date) AS sales_year,
    SUM(P.product_price) AS total_revenue
FROM
    PRODUCTS P
        JOIN
    SALES S ON P.product_id = S.product_id
GROUP BY P.product_id , sales_year
ORDER BY P.product_id , sales_year
    
-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT 
    YEAR(S.order_date) AS sales_year,
    C.country_name,
    SUM(P.product_price) AS total_revenue
FROM
    SALES S
        JOIN
    COUNTRIES C ON S.country_id = C.country_id
        JOIN
    PRODUCTS P ON S.product_id = P.product_id
GROUP BY sales_year , C.country_name
ORDER BY sales_year , total_revenue DESC

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

SELECT 
    PC.category_id,
    PC.category_name,
    SUM(P.product_price) AS total_revenue
FROM
    PRODUCTS P
        JOIN
    PRODUCT_CATEGORIES PC ON P.category_id = PC.category_id
        JOIN
    SALES S ON P.product_id = S.product_id
GROUP BY PC.category_id , PC.category_name
ORDER BY total_revenue DESC
LIMIT 1

-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

-- Approccio risolutivo 1: subquery
SELECT 
    P.product_id, P.product_name
FROM
    PRODUCTS P
WHERE
    P.product_id NOT IN (SELECT DISTINCT
            product_id
        FROM
            SALES)

-- Approccio risolutivo 2: left join
SELECT 
    P.product_id, P.product_name
FROM
    PRODUCTS P
        LEFT JOIN
    SALES S ON P.product_id = S.product_id
WHERE
    S.product_id IS NULL

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT 
    P.product_id,
    P.product_name,
    MAX(S.order_date) AS last_sale_date
FROM
    PRODUCTS P
        LEFT JOIN
    SALES S ON P.product_id = S.product_id
GROUP BY P.product_id , P.product_name
